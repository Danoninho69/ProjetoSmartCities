package br.com.meteorologia.smartcities;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;

@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
public class RioIT {

    @Autowired
    private TestRestTemplate restTemplate;

    @Test
    public void createRio() {
        Rio rio = new Rio("Tietê", 7, false); // Adicione o campo 'alerta' ao construtor de Rio

        // Ajuste o endpoint para "/rios"
        Rio[] rios = restTemplate.postForObject("/rios", rio, Rio[].class);

        assertNotNull(rios);
        assertEquals(1, rios.length);

        // Use .getRioname() e .getNumber() para comparar valores específicos
        assertEquals(rio.rioname(), rios[0].rioname());
        assertEquals(rio.number(), rios[0].number());

        assertThrows(RuntimeException.class,
            () -> restTemplate.postForObject("/rios", rio, Rio[].class));
    }
}
