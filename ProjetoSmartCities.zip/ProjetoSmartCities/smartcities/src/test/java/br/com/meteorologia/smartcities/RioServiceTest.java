package br.com.meteorologia.smartcities;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class RioServiceTest {

    @Autowired
    private RioService rioService;

    @Test
    public void testLoadRiosFromJson() {
        // Verifica se os rios foram carregados do JSON
        List<Rio> rios = rioService.create(new Rio("Teste", 1, false));
        assertNotNull(rios);
        assertTrue(rios.size() > 0); // Deve ter pelo menos um rio carregado do JSON
    }

    @Test
    public void createRio_ReturnsRios() {
        // Arrange
        Rio rio = new Rio("Tietê", 7, false);

        // Act
        List<Rio> rios = rioService.create(rio);

        // Assert
        assertEquals(1, rios.size());
        assertEquals(rio.rioname(), rios.get(0).rioname());
        assertEquals(rio.number(), rios.get(0).number());
    }

    @Test
    public void createRios_ThrowsException() {
        Rio rio = new Rio("Tietê", 7, false);
        rioService.create(rio);

        assertThrows(RuntimeException.class,
            () -> rioService.create(rio));
    }

    @Test
    public void createRio_RaisesAlert() {
        Rio rio = new Rio("Tietê", 8, false);
        List<Rio> rios = rioService.create(rio);

        assertEquals(1, rios.size());
        assertTrue(rios.get(0).alerta());
    }

    @Test
    public void createRio_NoAlert() {
        Rio rio = new Rio("Tietê", 7, false);
        List<Rio> rios = rioService.create(rio);

        assertEquals(1, rios.size());
        assertFalse(rios.get(0).alerta());
    }
}
