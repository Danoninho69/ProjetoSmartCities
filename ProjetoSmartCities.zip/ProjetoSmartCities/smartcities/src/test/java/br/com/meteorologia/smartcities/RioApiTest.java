package br.com.meteorologia.smartcities;

import io.restassured.RestAssured;
import io.restassured.module.jsv.JsonSchemaValidator;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class RioApiTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost";
        RestAssured.port = 8080;
    }

    @Test
    public void createRio_ValidatesStatusCodeAndResponse() {
        String rioJson = "{ \"rioname\": \"Tietê\", \"number\": 7, \"alerta\": false }";

        given()
            .contentType("application/json")
            .body(rioJson)
        .when()
            .post("/rios")
        .then()
            .statusCode(200)
            .body("[0].rioname", equalTo("Tietê"))
            .body("[0].number", equalTo(7))
            .body("[0].alerta", equalTo(false));
    }

    @Test
    public void createRio_ValidatesJsonSchema() {
        String rioJson = "{ \"rioname\": \"Tietê\", \"number\": 7, \"alerta\": false }";

        given()
            .contentType("application/json")
            .body(rioJson)
        .when()
            .post("/rios")
        .then()
            .statusCode(200)
            .body(JsonSchemaValidator.matchesJsonSchemaInClasspath("rio-schema.json"));
    }
}
