package br.com.meteorologia.smartcities;

import java.io.IOException;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class RioService {
    private static final Logger logger = LoggerFactory.getLogger(RioService.class);
    List<Rio> rios = new ArrayList<>();

    public RioService() {
        loadRiosFromJson();
    }

    private void loadRiosFromJson() {
        ObjectMapper mapper = new ObjectMapper();
        try {
            rios = mapper.readValue(Paths.get("Rios.json").toFile(), new TypeReference<List<Rio>>() {});
            logger.info("Rios carregados do JSON: {}", rios);
        } catch (IOException e) {
            logger.error("Erro ao carregar rios do JSON", e);
        }
    }

    public List<Rio> create(Rio rio) {
        if (rios.contains(rio))
            throw new RuntimeException();

        if (isAlerta(rio)) {
            rio = new Rio(rio.rioname(), rio.number(), true);
        } else {
            rio = new Rio(rio.rioname(), rio.number(), false);
        }

        rios.add(rio);
        return rios;
    }

    private boolean isAlerta(Rio rio) {
        int capacidadeMaxima = 10;
        int limiteAlerta = (int) (capacidadeMaxima * 0.8);

        return rio.number() >= limiteAlerta;
    }
}
