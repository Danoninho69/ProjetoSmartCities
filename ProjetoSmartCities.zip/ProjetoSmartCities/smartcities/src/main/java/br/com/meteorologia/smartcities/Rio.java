package br.com.meteorologia.smartcities;

public record Rio(String rioname, int number, boolean alerta) {
}
